import torch
import csv
from torch.utils.data.sampler import *
import numpy as np
import sys, copy, math, time, pdb
import pickle as pickle
import scipy.io as sio
import scipy.sparse as ssp
import os.path
import random
import argparse
import gc
import time
from util_functions import *
from torch_geometric.data import DataLoader
from model import *
from torch.utils.data import TensorDataset
from model import *
from sklearn import metrics
from sklearn.metrics import average_precision_score
from torch.nn.utils.rnn import pad_sequence,pack_padded_sequence,pack_sequence,pad_packed_sequence
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')



def mycollate_fn(batch):
    print('----------------')
    
    x_list = []
    y_list = []
    seq_list = []
    edge_list = []
    for data in batch:
        #print(data)
        #data.sort(key=lambda x: len(x[2]), reverse=True)
        seq_list.append(data['num_nodes'])
        x_list.append(data['x'])
        y_list.append(data['y'])
        edge_list.append(data['edge_index'])
    data = [x_list, y_list, seq_list, edge_list]
    print(data)
    data.sort(key=lambda x: len(x[2]), reverse=True)
    data.x = pad_sequence(data.x, batch_first=True).float()    
    data = data.unsqueeze(-1)
    data = pack_padded_sequence(data, seq_len, batch_first=True, enforce_sorted = False)
    
    return data
def parse(print_help=False):
    parser = argparse.ArgumentParser(description='Link Prediction')
    # general settings
    parser.add_argument('--data-name', default='f', help='dataset name')
    parser.add_argument('--train-name', default=None, help='train name')
    parser.add_argument('--test-name', default=None, help='test name')
    parser.add_argument('--max-train-num', type=int, default=10000, 
                        help='set maximum number of train links (to fit into memory)')
    parser.add_argument('--no-cuda', action='store_true', default=False,
                        help='disables CUDA training')
    parser.add_argument('--seed', type=int, default=1, metavar='S',
                        help='random seed (default: 1)')
    parser.add_argument('--test-ratio', type=int, default=10,
                        help='ratio of test links')
    # model settings
    parser.add_argument('--hop', default=2, metavar='S', 
                        help='enclosing subgraph hop number, \
                        options: 1, 2,..., "auto"')
    parser.add_argument('--max-nodes-per-hop', default=100, 
                        help='if > 0, upper bound the # nodes per hop by subsampling')
    parser.add_argument('-seed', type=int, default=1, help='seed')
    parser.add_argument('--lr', type=float, default=2e-3, help='learning ratio')
    parser.add_argument('--dropout-rate', type=float, default=0.4, help='dropout rate')
    parser.add_argument('--epoch', type=int, default=12, help='epoches')
    parser.add_argument('--simw', type=int, default=2, help='simw')
    parser.add_argument('--layer', type=int, default=3, help='layer')
    parser.add_argument('--hidden', type=int, default=128, help='hidden')
    parser.add_argument('--pro', type=int, default=1, help='probability of negative and positive samples')


    args = parser.parse_args()
    args.cuda = not args.no_cuda and torch.cuda.is_available()
    if print_help:
        parser.print_help()
    return args
'''
class MySequentialSampler(SequentialSampler):
    def __init__(self, data_source, num_data=None):
        self.data_source = data_source
        self.my_list = list(range(len(self.data_source)))
        random.shuffle(self.my_list)
        if num_data is None:
            self.num_data = len(self.my_list)
        else:
            self.num_data = num_data
            self.my_list = self.my_list[:num_data]

    def __iter__(self):
        return iter(self.my_list)

    def __len__(self):
        return self.num_data

    def shuffle(self):
        self.my_list = list(range(len(self.data_source)))
        random.shuffle(self.my_list)
        self.my_list = self.my_list[:self.num_data]
'''     

def SLGCN(args, fold, A, train_pos, train_neg, test_pos, test_neg, attributes=None,attributes_asso=None):
    #Train and apply classifier
    train_graphs, test_graphs, max_n_label = links2subgraphs(A, train_pos, train_neg, test_pos, test_neg, args.hop, args.max_nodes_per_hop, attributes,attributes_asso)
    print(max_n_label)

    print(('# train: %d, # test: %d' % (len(train_graphs), len(test_graphs))))
    train_lines = to_linegraphs(train_graphs, max_n_label)
    test_lines = to_linegraphs(test_graphs, max_n_label)


    max_node_num_train = 0
    for line in train_lines:
        if max_node_num_train < line.num_nodes:
            max_node_num_train = line.num_nodes    
    max_node_num_test = 0
    for line in test_lines:
        if max_node_num_test < line.num_nodes:
            max_node_num_test = line.num_nodes  
    max_node_num = max(max_node_num_train,max_node_num_test)
    print(max_node_num)

    # Model configurations
    hidden = args.hidden
    dropout = args.dropout_rate
    mode = 'gpu'
    learning_rate = args.lr
    batch_size = 8
    printAUC = True
    feat_dim = (max_n_label + 1)*2
    attr_dim = attributes.shape[1]
    latent_dim = []
    for i in range(args.layer):
        latent_dim.append(feat_dim)
   
    #train-test
    train_idxes = list(range(len(train_lines)))
    train_idxes = torch.LongTensor(train_idxes)
    test_idxes = list(range(len(test_lines)))
    test_idxes = torch.LongTensor(test_idxes)

    train_loader = DataLoader(train_idxes, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_idxes, batch_size=1, shuffle=False)
    classifier = SLGCN_model(feat_dim, hidden, attr_dim, latent_dim, dropout)
    
    if mode == 'gpu':
        classifier = classifier.to("cuda")
    optimizer = torch.optim.Adam(classifier.parameters(), lr=learning_rate)

    best_auc = 0
    counter = 0
    num_epochs = args.epoch
    for epoch in range(num_epochs):
        classifier.train()
        avg_loss = loop_dataset_gem(classifier, train_loader, train_lines, optimizer)
        if not printAUC:
            avg_loss[0][2] = 0.0
        print(('\033[92maverage training of epoch %d: loss %.5f acc %.5f auc %.5f ap %.5f\033[0m' % (epoch, avg_loss[0][0], avg_loss[0][1], avg_loss[0][2], avg_loss[0][3])))
            
        classifier.eval()
        test_loss = loop_dataset_gem(classifier, test_loader, test_lines)
        if not printAUC:
            test_loss[0][2] = 0.0
        print(('average test of epoch %d: loss %.5f acc %.5f auc %.5f ap %.5f' % (epoch, test_loss[0][0], test_loss[0][1], test_loss[0][2], test_loss[0][3])))
        model_path = os.path.join(args.path, 'model_{}.pth'.format(fold))        
        if best_auc < test_loss[0][2]:
            best_auc = test_loss[0][2]
            best_auc_acc = test_loss[0][3]
            print("save model for fold_{}".format(fold))
            torch.save(classifier.state_dict(),model_path)
            counter = 0
        else:
            counter = counter+1 
        if(counter>3):
            print('=======early stopiing========')
            break
    
    classifier.load_state_dict(torch.load(model_path))
    classifier.eval() 
    test_loader_adjust = DataLoader(test_idxes, batch_size=1, shuffle=False)
    val_test_loss, all_targets, all_scores= loop_val(classifier, test_loader_adjust,test_lines, 'test')
    print(('\033[43;1mbest performance of fold %d: loss %.5f acc %.5f auc %.5f ap %.5f\033[0m' % (fold, val_test_loss[0], val_test_loss[1], val_test_loss[2],val_test_loss[3])))
    
   
    del classifier # 删除模型
    gc.collect() # 回收内存
    return val_test_loss

#----------------------------------------------------------------------------
def loop_dataset_gem(classifier, loader, g_list, optimizer=None):
    total_loss = []
    all_targets = []
    all_scores = []
    all_acc = []
    all_logits =[]
    pbar = tqdm(loader, unit='batch')
    n_samples = 0
    for idx in pbar:
        batch_loss = []
        for ind in idx: 
            batch = g_list[ind]
            all_targets.extend(batch.y.tolist())
            logits, loss, acc = classifier(batch)
            batch_loss.append(loss)
            all_acc.append(acc)
            all_logits.append(logits.cpu().detach())
            all_scores.append(logits[:, 1].cpu().detach())
        batch_loss = torch.stack(batch_loss)
        if optimizer is not None:
            optimizer.zero_grad()
            loss = torch.mean(batch_loss)
            loss.backward()
            optimizer.step()
        else:
            loss = torch.mean(batch_loss)
                              
        loss = loss.data.cpu().detach().numpy()
        total_loss.append( np.array([loss]) * len(idx))                       
        n_samples += len(idx)  
        
    total_loss = np.array(total_loss)
    all_acc = np.array(all_acc)
    avg_loss = np.sum(total_loss, 0) / n_samples
    all_scores = torch.cat(all_scores).cpu().numpy()
    all_logits = torch.cat(all_logits).cpu().numpy()
    avg_acc = np.sum(all_acc, 0) / n_samples
    all_targets = np.array(all_targets)
    avg_precision = average_precision_score(all_targets, all_scores)
    fpr, tpr, _ = metrics.roc_curve(all_targets, all_scores, pos_label=1)
    auc = metrics.auc(fpr, tpr)
    avg_loss = np.concatenate(([avg_loss, avg_acc], [auc, avg_precision]))
    
    return  avg_loss,all_logits, all_targets, all_scores

def loop_val(classifier, loader, g_list, name=None):
    total_loss = []
    all_targets = []
    all_scores = []
    all_logits = []
    all_acc = []
    pbar = tqdm(loader, unit='batch')

    n_samples = 0
    for idx in pbar:
        for ind in idx:
            batch = g_list[ind]
            all_targets.extend(batch.y.tolist())
            logits, loss, acc = classifier(batch)
            all_scores.append(logits[:, 1].cpu().detach())
            loss_temp = loss.data.cpu().detach()
            total_loss.append(loss_temp)
            logits_temp = logits.data.cpu().detach()
            all_logits.append(logits_temp)
            all_acc.append(acc)
        n_samples += len(idx)
        
    total_loss = torch.cat(total_loss).cpu().numpy()
    all_logits = torch.cat(all_logits).cpu().numpy()
    avg_loss = np.sum(total_loss, 0) / n_samples
    all_targets = np.array(all_targets)
    all_acc = np.array(all_acc)
    avg_acc = np.sum(all_acc, 0) / n_samples
    if name:
        all_scores = torch.cat(all_scores).cpu().numpy()
        avg_precision = average_precision_score(all_targets, all_scores)
        fpr, tpr, _ = metrics.roc_curve(all_targets, all_scores, pos_label=1)
        auc = metrics.auc(fpr, tpr)
        avg_loss = np.concatenate(([avg_loss,avg_acc], [auc, avg_precision]))
    return  avg_loss, all_targets, all_scores
#----------------------------------------------------------------------------------------------
   

#-------main_functions---------------------------------------------------------------------
def train(args):    
    random.seed(args.seed)
    np.random.seed(args.seed) 
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.deterministic = True
    
    if args.hop != 'auto':
        args.hop = int(args.hop)
    if args.max_nodes_per_hop is not None:
        args.max_nodes_per_hop = int(args.max_nodes_per_hop)
        
    
    '''Prepare data'''
    args.file_dir = os.path.dirname(os.path.realpath('__file__'))
    args.res_dir = os.path.join(args.file_dir, 'results/{}'.format(args.data_name))
    if args.train_name is None:
        
         #读取关联矩阵
        args.data_dir = os.path.join(args.file_dir, 'data/{}-A.mat'.format(args.data_name))
        data = sio.loadmat(args.data_dir)
        net = data['net']

        #读取相似度信息
        sim_dir = os.path.join(args.file_dir, 'data/{}dataset.mat'.format(args.data_name))
        old_data = sio.loadmat(sim_dir)
        drug_sim = old_data["drug"].astype(np.float)
        disease_sim = old_data["disease"].astype(np.float)
        drug_num = drug_sim.shape[0]
        disease_num = disease_sim.shape[0]
        interactions = old_data["didr"].T
        drug_dis_matrix = np.mat(interactions)

        row1, col1 = np.diag_indices_from(drug_sim)
        drug_sim[row1,col1] = 0
        row2, col2 = np.diag_indices_from(disease_sim)
        disease_sim[row2,col2] = 0


        dr_deg = drug_sim.sum(axis=1)
        dr_deg_inv_sqrt = dr_deg**(-0.5)
        drug_sim= drug_sim*(dr_deg_inv_sqrt.reshape(-1, 1))
        drug_sim= drug_sim*(dr_deg_inv_sqrt.reshape(1, -1))
        drug_sim=drug_sim*args.simw

        dis_deg = disease_sim.sum(axis=1)
        dis_deg_inv_sqrt = dis_deg**(-0.5)
        disease_sim = disease_sim*(dis_deg_inv_sqrt.reshape(-1, 1))
        disease_sim = disease_sim*(dis_deg_inv_sqrt.reshape(1, -1))
        disease_sim=disease_sim*args.simw
        
        zero_drug = np.zeros((drug_num,disease_num))
        zero_dis = np.zeros((disease_num,drug_num))
        zero_drug_dis = np.mat(zero_drug)
        zero_dis_drug = np.mat(zero_dis)

        mat1 = np.hstack((drug_sim, drug_dis_matrix))
        mat2 = np.hstack((drug_dis_matrix.T, disease_sim))
        
        #节点特征矩阵
        HN_matrix = np.vstack((mat1, mat2))
        attributes = HN_matrix


        #读取异构网络
        args.data_dir = os.path.join(args.file_dir, 'data/{}-1.mat'.format(args.data_name))
        data_heter = sio.loadmat(args.data_dir)
        net_heter = data_heter['net']
        
        #-----路径
        args.path = 'runtime/{}/lr_{}_drop_{}_hop_{}_simw_{}_seed_{}_layer_{}_unit_{}/'.format(args.data_name, args.lr, args.dropout_rate, args.hop, args.simw, args.seed, args.layer, args.hidden)
        folder = os.path.exists(args.path)
        if not folder:            
            os.makedirs(args.path)          
            
      
        if False:
            net_ = net.toarray()
            assert(np.allclose(net_, net_.T, atol=1e-8))
            
        kfolder_enmurator = sample_neg(net, drug_num, disease_num, args.pro, args.test_ratio, max_train_num=args.max_train_num) #使用util_functions中的sample_neg采样

        for train_pos, train_neg, test_pos, test_neg, fold_id in kfolder_enmurator:

            train_pos = train_pos
            train_neg = train_neg
            test_pos = test_pos
            test_neg = test_neg
            print('------------------trian_pos in Main ---------------------------------')
            print(len(train_pos[0]))
            print('------------------trian_neg in Main ---------------------------------')
            print(len(train_neg[0]))
            print('------------------test_pos in Main ---------------------------------')
            print(len(test_pos[0]))
            print('------------------test_neg in Main ---------------------------------')
            print(len(test_neg[0]))

            #Train and apply classifier
            A = net_heter.copy()  # the observed network
            A[test_pos[0], test_pos[1]] = 0  # mask test links
            A[test_pos[1], test_pos[0]] = 0  # mask test links
            A.eliminate_zeros()

            val_test_loss = SLGCN(args, fold_id, A, train_pos, train_neg, test_pos, test_neg, attributes)
           
    else:
        args.train_dir = os.path.join(args.file_dir, 'data/{}'.format(args.train_name))
        args.test_dir = os.path.join(args.file_dir, 'data/{}'.format(args.test_name))
        train_idx = np.loadtxt(args.train_dir, dtype=int)
        test_idx = np.loadtxt(args.test_dir, dtype=int)
        max_idx = max(np.max(train_idx), np.max(test_idx))
        net = ssp.csc_matrix((np.ones(len(train_idx)), (train_idx[:, 0], train_idx[:, 1])), shape=(max_idx+1, max_idx+1))
        net[train_idx[:, 1], train_idx[:, 0]] = 1  # add symmetric edges
        net[np.arange(max_idx+1), np.arange(max_idx+1)] = 0  # remove self-loops
        #Sample negative train and test links
        train_pos = (train_idx[:, 0], train_idx[:, 1])
        test_pos = (test_idx[:, 0], test_idx[:, 1])
        train_pos, train_neg, test_pos, test_neg = sample_neg(net, train_pos=train_pos, test_pos=test_pos, max_train_num=args.max_train_num)

        

        
if __name__=="__main__":    
    args = parse(print_help=True)
    
    #print(args)
    train(args)    
