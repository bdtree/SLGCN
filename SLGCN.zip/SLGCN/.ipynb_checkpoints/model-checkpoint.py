# -*- coding: utf-8 -*-
"""
Created on Thu May 11 21:06:07 2023

@author: 77998
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Mar  6 20:03:49 2023

@author: 77998
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Sep 22 11:31:24 2019

@author: lei.cai
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
import torch_geometric.nn as gnn
import torch.nn as nn
from torch.autograd import Variable
from typing import List, Tuple, Dict
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
from torch.nn.utils.rnn import pad_sequence,pack_padded_sequence,pack_sequence,pad_packed_sequence

class CustomDropout(nn.Module):
    def __init__(self, p):
        super().__init__()
        self.dropout = (lambda x: x ) if p == 0 else nn.Dropout(p)
    
    def forward(self, input):
        return self.dropout(input)

class Structure_Enhanced_Message_Aggregation(Module):
    def __init__(self, in_features, out_features, bias=None):
        super(Structure_Enhanced_Message_Aggregation, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight_bi = Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()


    def reset_parameters(self):
        stdv_bi = 1. / math.sqrt(self.weight_bi.size(1))
        self.weight_bi.data.uniform_(-stdv_bi, stdv_bi)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)
            
    def forward(self, input, adj, reconstruct_matrix):
       
        adj = torch.mul(adj, reconstruct_matrix)
        with torch.no_grad():
            row_sum = torch.sum(adj, dim=1, keepdim=True)
            r_inv = torch.pow(row_sum, -0.5).flatten() 
            r_inv[torch.isinf(r_inv)] = 0.
            r_mat_inv = torch.diag(r_inv)
        
        adj = torch.matmul(r_mat_inv, adj)
        adj = torch.matmul(adj, r_mat_inv)
        
        support_bi = torch.mm(input, self.weight_bi)
        output = torch.spmm(adj, support_bi)
       
        if self.bias is not None:
            output = output + self.bias
        else:
            output
        return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'
    
        

class Construction_Relation_Matrix(nn.Module):

    def __init__(self, act=nn.Sigmoid):
        super(Construction_Relation_Matrix, self).__init__()
        self.act = act() if act is not None else nn.Identity()

    def forward(self, feature):
        R = feature
        D = feature
        x = R@D.T
        outputs = self.act(x)
        return outputs
    
class SLGCN_model(nn.Module):
    def __init__(self, input_dim, hidden_size, attr_dim, latent_dim=[32, 32, 32], with_dropout=0.4):
        super(SLGCN_model, self).__init__()
        self.input_dim = input_dim
        self.latent_dim = latent_dim
        self.attr_dim = attr_dim*2
        self.sim_dim = attr_dim
        l_dim = latent_dim[-1]
        
        self.with_dropout = with_dropout 
        self.embedding_dim = hidden_size
        
        conv = gnn.SAGEConv
        self.conv_params = nn.ModuleList()
        self.conv_params.append(conv(input_dim, latent_dim[0]))
        for i in range(1, len(latent_dim)):
            self.conv_params.append(conv(latent_dim[i],latent_dim[i]))

        self.rm = Construction_Relation_Matrix(act=nn.Sigmoid)
        
        conv2 = Structure_Enhanced_Message_Aggregation
        self.conv2_params = nn.ModuleList()
        self.conv2_params.append(conv2(self.attr_dim,hidden_size))
        for i in range(1, len(latent_dim)):
            self.conv2_params.append(conv2(hidden_size,hidden_size)) 
      
        self.U_o = nn.Parameter(torch.Tensor(hidden_size,hidden_size))
        self.V_o = nn.Parameter(torch.Tensor(hidden_size,hidden_size))
        self.b_o = nn.Parameter(torch.Tensor(hidden_size))
        self.init_weights()
        
        self.linear_sim = nn.Linear(self.attr_dim, hidden_size)
        self.linear = nn.Linear(hidden_size, 2)
        nn.init.xavier_uniform_(self.linear_sim.weight)
        nn.init.xavier_uniform_(self.linear.weight)
      
        self.dropout = nn.Dropout(self.with_dropout)
        
    def init_weights(self):
        stdv = 1.0 / math.sqrt(self.embedding_dim)
        for weight in [self.U_o,self.V_o,self.b_o]:
            weight.data.uniform_(-stdv, stdv)    
    def forward(self, data):
        data.to(torch.device("cuda"))
        x, edge_index, y = data.x, data.edge_index, data.y
        
        zero_adj = torch.zeros((data.num_nodes,data.num_nodes))
        zero_adj[edge_index[0],edge_index[1]] = 1
        zero_adj[edge_index[1],edge_index[0]] = 1
        zero_adj = zero_adj.to(torch.device("cuda"))
        with torch.no_grad():
            row_sum = torch.sum(zero_adj, dim=1, keepdim=True)
            r_inv = torch.pow(row_sum, -0.5).flatten()  # np.power(rowsum, -1).flatten()
            r_inv[torch.isinf(r_inv)] = 0.
            r_mat_inv = torch.diag(r_inv)
        dno_adj = torch.matmul(r_mat_inv, zero_adj)
        dno_adj = torch.matmul(dno_adj, r_mat_inv)
        
        sim_embeddings = x[:,self.input_dim:]
        sim_embeddings =  sim_embeddings.float()
        output = sim_embeddings
        distance_embedding = x[:,0:self.input_dim]
        cur_message_layer = distance_embedding
        lin_sim_embeddings = self.linear_sim(sim_embeddings)
        
        lv = 0
        while lv < len(self.latent_dim):
            
            cur_message_layer = self.conv_params[lv](cur_message_layer, edge_index)
            if lv!=len(self.latent_dim)-1:
                cur_message_layer = self.dropout(cur_message_layer)
            relation_matrix = self.rm(cur_message_layer) 

   
            output = self.conv2_params[lv](output,zero_adj, relation_matrix)
    
            o_t = torch.sigmoid(lin_sim_embeddings @ self.U_o.to('cuda') + output @ self.V_o.to('cuda') + self.b_o.to('cuda')).to('cuda')
            x = lin_sim_embeddings + output
            output = o_t * torch.tanh(x).to('cuda')
            
            if lv==len(self.latent_dim)-1:
                output = nn.ReLU()(output)
            if lv!=len(self.latent_dim)-1:
                output = self.dropout(output)
            lv += 1 

        outputf = output
        idx = [0]
        outputs = outputf[idx,:]
        logits = self.linear(outputs)
        logits = F.log_softmax(logits, dim=1)
    
        if y is not None:
            y = Variable(y)
            loss = F.nll_loss(logits, y, reduction='none')
            pred = logits.data.max(1, keepdim=True)[1]
            acc = pred.eq(y.data.view_as(pred)).cpu().sum().item() / float(y.size()[0])
            return logits, loss, acc
        else:
            return logits
